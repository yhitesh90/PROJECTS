package com.jforce.springboot_voting_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootVotingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
