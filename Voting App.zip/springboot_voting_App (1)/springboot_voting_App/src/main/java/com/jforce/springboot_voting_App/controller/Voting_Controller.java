package com.jforce.springboot_voting_App.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.jforce.springboot_voting_App.dto.User;
import com.jforce.springboot_voting_App.dto.Vote;
import com.jforce.springboot_voting_App.repository.Vote_Repository;
import com.jforce.springboot_voting_App.repository.Voting_Repository;
import com.jforce.springboot_voting_App.service.VotingImplementation;

@Controller

public class Voting_Controller {
	@Autowired
	private VotingImplementation service;
	@Autowired
	private Voting_Repository repository;
	private Vote_Repository repository1;

	@GetMapping("/signup")
	public String Form(Model model) {
		model.addAttribute("voting", new User());
		return "signup";
	}

	@PostMapping("/signup")
	public String votingSubmit(@ModelAttribute("voting") User user, Model model) {
		System.out.println("Data Inserted" + user);
		repository.save(user);
		System.out.println("Data Entered");
		model.addAttribute("voting", user);
		return "index";
	}

	@GetMapping("/login")
	public String showVotinglogin(Model model) {
		User user = new User();
		model.addAttribute("voting", user);
		return "index";
	}

	@PostMapping("/login")
	public String validate(@ModelAttribute("voting") User user, Model model) {
		System.out.println(user.getUsrername() + "\n" + user.getPassword());
		for (User uv : repository.findAll()) {
			System.out.println(user.getUsrername());
			if (user.getUsrername().equals(uv.getUsrername()) && user.getPassword().equals(uv.getPassword())) {
				model.addAttribute("userId", uv.getId());
				return "voting";
			}else if (user.getUsrername().equals("Admin") && user.getPassword().equals("Admin")) {
				return "admin";
			}

		}
		return "index";

	}

	@Autowired
//		private  Vote_Repository repository2;

	public Voting_Controller(Voting_Repository repository, Vote_Repository repository1) {
		super();
		this.repository = repository;
		this.repository1 = repository1;
	}

	@GetMapping("/letsvote")
	public String handleVote(Model model) {
		Vote vote = new Vote();
		model.addAttribute("vote", vote);
		return "voting";
	}

	@PostMapping("/letsvote")
	public String handleVote(@ModelAttribute("voting") Vote vote, Model model) {

		System.out.println("Data Inserted" + vote);
		repository1.save(vote);
		System.out.println("Data Entered");
		model.addAttribute("voting", vote);
		return "votedone";
	}
	

	public Voting_Controller() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public VotingImplementation getService() {
		return service;
	}

	public void setService(VotingImplementation service) {
		this.service = service;
	}

	public Voting_Repository getRepository() {
		return repository;
	}

	public void setRepository(Voting_Repository repository) {
		this.repository = repository;
	}

	public Vote_Repository getRepository1() {
		return repository1;
	}

	public void setRepository1(Vote_Repository repository1) {
		this.repository1 = repository1;
	}


}
