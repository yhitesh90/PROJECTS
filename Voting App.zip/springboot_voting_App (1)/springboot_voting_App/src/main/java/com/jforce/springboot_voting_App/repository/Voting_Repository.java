package com.jforce.springboot_voting_App.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jforce.springboot_voting_App.dto.User;
import com.jforce.springboot_voting_App.dto.Vote;
@Repository
public interface Voting_Repository extends JpaRepository<User, String>{

	void save(Vote vote);
	




 
 
	

	
}
