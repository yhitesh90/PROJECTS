package jakarta.validation.constraints;

public @interface NotNull {

}
