package com.rud.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
